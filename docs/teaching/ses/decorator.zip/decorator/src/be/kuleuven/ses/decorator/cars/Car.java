package be.kuleuven.ses.decorator.cars;

public interface Car {
    public void assemble(); // build stuff
}
