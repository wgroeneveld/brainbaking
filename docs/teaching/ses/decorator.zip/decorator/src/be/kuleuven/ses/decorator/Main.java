package be.kuleuven.ses.decorator;

public class Main {
	public static void main(String[] args) {
		System.out.println("here's a factory, let's start the assembly, shall we?");
		Factory vwFactory = new Factory();

		// TODO use the factory
	}
}
