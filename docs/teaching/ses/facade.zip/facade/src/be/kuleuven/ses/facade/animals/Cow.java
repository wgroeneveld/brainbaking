package be.kuleuven.ses.facade.animals;

public class Cow {
	// you know the drill
}
