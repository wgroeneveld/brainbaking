package be.kuleuven.ses.factory.tickets;

public abstract class Ticket {

    public abstract String getMovie();
    public abstract int getPrice();
}
