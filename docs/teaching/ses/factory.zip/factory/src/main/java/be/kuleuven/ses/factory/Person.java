package be.kuleuven.ses.factory;

public class Person {
    private final int age;

    public int getAge() {
        return age;
    }

    public Person(int age) {
        this.age = age;
    }
}
